function [T,Tarray] = import_data(nof,band_name)
% band name should be in the format of 'test0925_B1_'
%read data from sub folder
filefolder = 'C:\Users\jiaor\Desktop\LAB codes and signals\codes\Data Processing Old Amplifier with GUI (1005)';
%subfile name (with all the data sheet)
subfile = 'Data\';
f = fullfile(filefolder,subfile);
%% loop for reading in files:
for ii = 1:nof
    filename = [f, band_name num2str(ii) '.txt'];
    
    if (ii == 1)
    %%opts = detectImportOptions(filename,'Delimiter','\n');
    %opts.Datalines = [1:100];
        T = readtable(filename);
        T.Properties.VariableNames={num2str(ii) num2str(ii+1)};
    else
        T = [T,readtable(filename)];
        T.Properties.VariableNames(ii*2-1:ii*2)={num2str(ii*2-1) num2str(ii*2)};
        %T4.Properties.VariableNames={'A1_1','A2_1','A1_2','A2_2','A1_3','A2_3'};
    end
end
%% change the table to array
Tarray = table2array(T);
end