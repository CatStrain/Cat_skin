function [figure_3,figure_4,stdev]= standev1006(combine,T_without_offset, poly_fit,e_rows,e_columns)
% Standard Deviation
% calculate every rows' std(without offset)
[r1,c1]=size(e_rows);
[r2,c2]=size(e_columns);
N = [1:c1];
stdev = std(T_without_offset')/c2;% depends on the size of data

figure_3 = errorbar(N,combine,stdev);
xlabel('Counts(ms)');
ylabel('Signal Magnitude');
title('Signal plotting with standerd deviation(Band1)');
legend('error bar');
figure_4 = errorbar(N,poly_fit,stdev,'r');
xlabel('Counts(ms)');
ylabel('Signal Magnitude');
title('Curve fitting with standerd deviation(Band1)');
legend('error bar');
%% save the standev to table

% Table3 = array2table([N',combine,poly_fit',stdev']);
% save('standev_2.mat', 'N','combine','poly_fit','stdev');
end