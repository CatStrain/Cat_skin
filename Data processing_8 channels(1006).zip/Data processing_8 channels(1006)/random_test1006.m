%% data preparation:
%strain gauge total reading numbers:
strain_gauge_lecture = 800;
%stran gauge numbers
strain_gauges = 8; 
%data row numbers
total_batches = strain_gauge_lecture/strain_gauges;
%change number to array
Number = [1:total_batches]';
%% Open the subfolder and select the Data

% notice that the data might need to be pasted into the Data/ subfolder
% first.
filefolder = 'C:\Users\jiaor\Desktop\LAB codes and signals\codes\Data processing_8 channels(1006)';
%subfile name (with all the data sheet)
subfile = 'Data\';
f = fullfile(filefolder,subfile);
filename = [f, 'test1012_B1_15.txt'];% put the name here
%% import data then store them into Table and Array
%[T,Tarray] = [T,Tarray] = import_data1006(nof,band_name,column_number);
column_number = 5:6; 
% ***** IMPORTANT
%for data in 0926: for Band 1 column_number = 7:8;
% for Band 2 column_number = 5:6
% for Band 3 column_number = 3:4
% for Band 4 column_number = 1:2
%%% for data in 1012:
% for Band 1 column_number = 5:6;
% for Band 2 column_number = 7:8
% for Band 3 column_number = 3:4
% for Band 4 column_number = 1:2

%% Read data into Table
T_1 = readtable(filename);
T = T_1{:,column_number};
%% Plot the data with first line and offset eliminated
e_rows = [1: 99];
e_columns = [1:2];
front_rows = 3;
figure(1)
[T_without_offset,figure_1] = offset1006(T,front_rows,e_rows,e_columns);
