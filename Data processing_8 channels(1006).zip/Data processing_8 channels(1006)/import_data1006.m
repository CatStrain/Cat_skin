function [T] = import_data1006(nof,band_name,column_number)
% band name should be in the format of 'test0925_B1_'
%read data from sub folder
filefolder = 'C:\Users\jiaor\Desktop\LAB codes and signals\codes\Data processing_8 channels(1006)';
%subfile name (with all the data sheet)
subfile = 'Data\';
f = fullfile(filefolder,subfile);
%% loop for reading in files:
for ii = 1:nof
    filename = [f, band_name num2str(ii) '.txt'];
    
     if ii == 1
    %%opts = detectImportOptions(filename,'Delimiter','\n');
    %opts.Datalines = [1:100];
        T_1 = readtable(filename);
        T = T_1{:,column_number};%% read certain columns for Band_1
        %%T.Properties.VariableNames(1:2)={num2str(ii) num2str(ii+1)};
    else
        T_1 = readtable(filename);
        %T = T_1{:,7:8};
        T = [T,T_1{:,column_number}];
       % T.Properties.VariableNames(ii*2-1:ii*2)={num2str(ii*2-1) num2str(ii*2)};
        %T4.Properties.VariableNames={'A1_1','A2_1','A1_2','A2_2','A1_3','A2_3'};
    end
end
%% change the table to array
%Tarray = table2array(T);
% %% Save the table into .mat
% % for example: T2 for band 2
% Table = array2table(T);
% save('T2.mat', 'Table')
end