function [figure_5,repetitive_1,re]= repetitive1006(T_without_offset,e_rows,e_columns,Number)

T_without_offset = array2table(T_without_offset);
[r1,c1]=size(e_rows);
[r2,c2] =size(e_columns);
c2 = c2/2;
for i = 1:c2
    for j = 1:c1
      if j == 1
          repetitive_1 = mean(T_without_offset{j,[2*i-1 2*i]});
      else
          repetitive_1 = [repetitive_1;mean(T_without_offset{j,[2*i-1 2*i]})];
      end
    end
        if i == 1
            re = repetitive_1;
        else
           re = [re,repetitive_1];
        end

    
    
      % repetitive_2 = [repetitive_1,mean(T_without_offset{:,[2*i-1 2*i]})
end

 Number = Number(e_rows,:);
 figure_5 = plot(Number',re);
 xlabel('Counts(ms)');
 ylabel('Signal Magnitude');
 title('Signal plotting');
 legend('Test_1','Test_2','Test_3','Test_4','Test_5','Test_6','Test_7','Test_8','Test_9');
 grid on;

%% Save to .mat
% N_table = array2table(Number);
% re = array2table(re);
% Table = [re,N_table];
% Table.Properties.VariableNames={'Test_1','Test_2','Test_3','Test_4','Test_5','Test_6','Test_7','Test_8','Test_9','N_table'};
% save('repetitive_2.mat', 're','N_table')

end