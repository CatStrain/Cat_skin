%% data preparation:
%strain gauge total reading numbers:
strain_gauge_lecture = 800;
%stran gauge numbers
strain_gauges = 8; 
%data row numbers
total_batches = strain_gauge_lecture/strain_gauges;
%change number to array
Number = [1:total_batches]';

%% import data then store them into Table and Array
%[T,Tarray] = [T,Tarray] = import_data1006(nof,band_name,column_number);
column_number = 3:4; 
% ***** IMPORTANT: for Band 1 column_number = 7:8;
% for Band 2 column_number = 5:6
% for Band 3 column_number = 3:4
% for Band 4 column_number = 1:2
[T] = import_data1006(9,'test0926_B3_',column_number);
% Explanation :
% 1) 'band_name' should be in the format of 'test0925_B*_',for example, B1 =
% band 1 testing data
% 2) 'nof' is the number of data files
%% eliminate the offset for each column:
% Firstly,determine how many rows and columns from the data are usable
% to be noticed, the firstline of data is eliminated from the data
e_rows = [1: 99];
e_columns = [1:18];%2*9
% ***Important: some data column need to be eliminated or they will infect
% the whole results

%[T_without_offset,figure_1] = offset(T,front_rows,Number,e_rows,e_columns)
figure(1)
[T_without_offset,figure_1] = offset1006(T,2,e_rows,e_columns);

% Explanation :
% figure_1 the plot of x-rows and y-Data with offset eliminated 
% e_rows,e_columns are the processed rows and columns 
% front_rows means how many rows used to take the average for calculating the offset

%% Curve fitting
figure(2)
[combine, poly_fit,figure_2] = combine_polynomial_fit1006(T_without_offset,Number,e_rows,e_columns);
%% Standard Deviation
figure(3)
[figure_3,figure_4,stdev]= standev1006(combine,T_without_offset, poly_fit,e_rows,e_columns);
