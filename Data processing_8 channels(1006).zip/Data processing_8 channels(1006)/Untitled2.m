

T_without_offset = array2table(T_without_offset);
[r1,c1]=size(e_rows);
[r2,c2] =size(e_columns);
c2 = c2/2;
for i = 1:c2
    for j = 1:c1
      if j == 1
          repetitive_1 = mean(T_without_offset{j,[2*i-1 2*i]});
      else
          repetitive_1 = [repetitive_1;mean(T_without_offset{j,[2*i-1 2*i]})];
      end
      
      if i == 1
           re = repetitive_1;
        else
            re = [re,repetitive_1];
        
      end
    end
end
      % repetitive_2 = [repetitive_1,mean(T_without_offset{:,[2*i-1 2*i]})


 Number = Number(e_rows,:);
 figure_5 = plot(Number',repetitive_1);
% xlabel('Counts(ms)');
% ylabel('Signal Magnitude');
% title('Signal plotting');
% legend('repetive');
% grid on;


