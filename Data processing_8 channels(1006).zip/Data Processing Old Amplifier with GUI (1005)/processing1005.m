%% data preparation:
%strain gauge total reading numbers:
strain_gauge_lecture = 200;
%stran gauge numbers
strain_gauges = 2; 
%data row numbers
total_batches = strain_gauge_lecture/strain_gauges;
%change number to array
Number = [1:total_batches]';

%% import data then store them into Table and Array
%[T,Tarray] = import_data(nof,band_name);
[T,Tarray] = import_data(9,'test0925_B3_');
% Explanation : 
% 1) 'band_name' should be in the format of 'test0925_B*_',for example, B1 =
% band 1 testing data
% 2) 'nof' is the number of data files
%% eliminate the offset for each column:
% Firstly,determine how many rows and columns from the data are usable
% to be noticed, the firstline of data is eliminated from the data
e_rows = [1: 99];
e_columns = [1:18];
%[T_without_offset,figure_1] = offset(T,Tarray,front_rows,Number,e_rows,e_columns)
figure(1)
[T_without_offset,figure_1] = offset(T,Tarray,2,e_rows,e_columns);
% Explanation :
% figure_1 the plot of x-rows and y-Data with offset eliminated 
% e_rows,e_columns are the processed rows and columns 
% front_rows means how many rows used to take the average for calculating the offset

%Curve fitting
figure(2)
[combine, poly_fit,figure_2] = combine_polynomial_fit(T_without_offset,Number,e_rows,e_columns);

figure(3)
[figure_3,figure_4]= standev(T_without_offset,e_rows,e_columns);

% N = Number(e_rows,:);
% stdev = std(T_without_offset')/17;% depends on the size of data
% Number = Number(e_rows,:);
% figure(3)
% errorbar(N,combine,stdev);
% xlabel('Counts(ms)');
% ylabel('Signal Magnitude');
% title('Signal plotting with standerd deviation(Band1)');
% legend('error bar');