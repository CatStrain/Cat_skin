function [figure_3,figure_4]= standev(combine,T_without_offset,e_rows,e_columns)
% Standard Deviation
% calculate every rows' std(without offset)
[r1,c1]=size(e_rows);
[r2,c2]=size(e_columns);
N = [1:c1];
stdev = std(T_without_offset')/c2;% depends on the size of data

figure_3 = errorbar(N,combine,stdev);
xlabel('Counts(ms)');
ylabel('Signal Magnitude');
title('Signal plotting with standerd deviation(Band1)');
legend('error bar');
figure_4 = errorbar(N,d,stdev,'r');
xlabel('Counts(ms)');
ylabel('Signal Magnitude');
title('Curve fitting with standerd deviation(Band1)');
legend('error bar');
end