function [T_without_offset,figure_1] = offset(T,Tarray,front_rows,e_rows,e_columns)
%[r1,c1]=size(e_rows);
%[r2,c2]=size(e_columns);

%eliminate the first row
T = T{2:end,:};
Tarray = Tarray([2:end],:);
%calculate the offset
offset = mean(T(1:front_rows,:));
T_without_offset = Tarray-offset;
% to eliminate certain data columns and rows:
T_without_offset = T_without_offset(e_rows,e_columns);

figure_1 = plot(e_rows',T_without_offset);
legend('A1','A2','A3','A4','A5','A6','A7','A8','A9','A10','A11','A12','A13','A14','A15','A16','A17','A18','A19','A20','A21','A22','A23','A24','A25');
title('Signal plotting');

end