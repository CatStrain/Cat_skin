function [combine, poly_fit,figure_2] = combine_polynomial_fit(T_without_offset,Number,e_rows,e_columns)
% take the average by columns
T_without_offset = array2table(T_without_offset);
[r,c]=size(e_rows);
for i = 1:c
    if i == 1
        combine = mean(T_without_offset{i,:});
    else
        combine = [combine;mean(T_without_offset{i,:})];
    end
end

%Curve fitting
%****Important: we can use curve fitting toolbox in MATLAB for expressions
% or using function:
% https://blog.csdn.net/zhanshen112/article/details/79778530
Number = Number(e_rows,:);
%combine = combine(e_rows,e_columns);

figure_2 = plot(Number',combine);
hold on;
grid on;
c = polyfit(Number',combine',3);%number means how many times the curve repeats fitting(can not over 4)
poly_fit = polyval(c,Number',1);
plot(Number',poly_fit, 'r' )
xlabel('Counts(ms)');
ylabel('Signal Magnitude');
title('Signal plotting');
legend('Combine','Curve fitting');
grid on;
hold off;

end

